# Phase 5B — Seasonal Analysis (2022–2025 Baseline)

## Scope
The analysis uses the validated 809-row Maharashtra IDSP/NCDC analytical dataset and the Phase 5A disease-family mapping. The completed-year baseline is 2022–2025; 2026 W01–W32 is excluded from baseline seasonal estimation.

## Method
- Unit of observation: government-reported Maharashtra outbreak event records, not population incidence.
- Primary seasonal measure: monthly outbreak-event frequency.
- Seasonal indices are equal-year weighted: each year's monthly distribution is converted to shares, then averaged across 2022–2025. Index 1.0 represents the average monthly share.
- Case totals are retained as a secondary burden measure because outbreak sizes are highly uneven.
- Weekly distributions are retained for epidemiological timing.
- Exploratory Kruskal–Wallis tests compare weekly outbreak-event counts across calendar months; p-values are treated as exploratory evidence of non-uniform temporal distribution, not proof of causation.

## Core results
- **Dengue:** 204 outbreak events, 3,144 reported cases and 93 deaths in 2022–2025. Equal-year-weighted event seasonality peaks in **Sep** (index 1.97); case-burden seasonality peaks in **Aug** (index 2.10). Highest pooled weekly event count: W42 (17 events). Yearly event peaks: 2022 Sep, 2023 Oct, 2024 Jun, 2025 Aug. Kruskal–Wallis H=35.33, p=0.000219.
- **Acute Diarrheal Disease:** 153 outbreak events, 9,050 reported cases and 93 deaths in 2022–2025. Equal-year-weighted event seasonality peaks in **Jun** (index 1.88); case-burden seasonality peaks in **Oct** (index 1.70). Highest pooled weekly event count: W28 (9 events). Yearly event peaks: 2022 Dec, 2023 Jun, 2024 Jul, 2025 Oct. Kruskal–Wallis H=16.25, p=0.1321.
- **Malaria:** 70 outbreak events, 2,133 reported cases and 51 deaths in 2022–2025. Equal-year-weighted event seasonality peaks in **Jun** (index 2.69); case-burden seasonality peaks in **May** (index 2.86). Highest pooled weekly event count: W28 (6 events). Yearly event peaks: 2022 May, 2023 May, 2024 Jul, 2025 Jun. Kruskal–Wallis H=26.50, p=0.005459.
- **Food Poisoning:** 69 outbreak events, 5,927 reported cases and 29 deaths in 2022–2025. Equal-year-weighted event seasonality peaks in **May** (index 2.51); case-burden seasonality peaks in **May** (index 3.52). Highest pooled weekly event count: W06 (4 events). Yearly event peaks: 2022 May, 2023 Feb, 2024 Feb, 2025 Jan. Kruskal–Wallis H=26.39, p=0.005679.
- **Chikungunya:** 43 outbreak events, 701 reported cases and 0 deaths in 2022–2025. Equal-year-weighted event seasonality peaks in **May** (index 1.69); case-burden seasonality peaks in **Sep** (index 2.63). Highest pooled weekly event count: W42 (3 events). Yearly event peaks: 2022 May, 2023 Jul, 2024 Jun, 2025 Aug. Kruskal–Wallis H=12.12, p=0.3549.

## Interpretation safeguards
- A seasonal peak in outbreak-event frequency means that reported outbreak events were concentrated in that period; it does not establish population incidence, transmission intensity, or causality.
- Differences between event-frequency peaks and case-burden peaks are important because one large outbreak can contribute many cases but only one event record.
- Year-to-year peak shifts are retained rather than averaged away; they are part of the interpretation.
- 2026 is reserved for a separate current-year comparison because the official archive currently ends at Week 32; the NCDC archive lists 2026 Weeks 1–32 and the completed-year archives separately. citeturn0view0

## Data products
01_MONTHLY_DISTRIBUTION.csv; 02_SEASONAL_INDICES.csv; 03_WEEKLY_DISTRIBUTION.csv; 04_YEARLY_DISTRIBUTION.csv; 05_SEASONAL_STATISTICS.csv; plus presentation-ready PNG charts.